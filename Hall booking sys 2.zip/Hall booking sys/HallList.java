import java.util.ArrayList;

public class HallList {
    private ArrayList<Hall> hallList;

    public HallList() {
        hallList = new ArrayList<Hall>();
    }

    public HallList(ArrayList<Hall> hallList) {
        this.hallList = hallList;
    }

    public ArrayList<Hall> getHallList() {
        return hallList;
    }

    public void setHallList(ArrayList<Hall> hallList) {
        this.hallList = hallList;
    }


}