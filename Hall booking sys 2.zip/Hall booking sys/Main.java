import java.util.Scanner;
import java.util.ArrayList;

/**
 * Write a description of class Main here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Main {
    private ArrayList<User> userList;
    private ArrayList<Hall> hallList;
    Scanner scan = new Scanner(System.in);
    private boolean userStatus;
    private User user;
    
    public Main()
    {
        user = new User();
        userStatus = false;
        userList = new ArrayList<User>();
        hallList = new ArrayList<Hall>();
    }

    public void system() 
    {
        
        Customer customer = new Customer("customerStatus", 1, 2, 3, "bookingHistory", "customer", "customer", "customer", "1");
        Administrator admin = new Administrator("admin", "admin", "admin", "3");
        Owner owner1 = new Owner(143214231, 444999599, 300, "owner1", "owner1", "owner1", "2");
        Owner owner2 = new Owner(112342342, 340433299, 500, "owner2", "owner2", "owner2", "2");
        Owner owner3 = new Owner(122223333, 200998699, 0, "owner3", "owner3", "owner3", "2");
        
        userList.add(customer);
        userList.add(admin);
        userList.add(owner1);
        userList.add(owner2);
        userList.add(owner3);

        Hall hall1 = new Hall("Melbourne SkyHigh Apartments", "nice views", true, 4);
        Hall hall2 = new Hall("Crown Metropol Melbourne", "nice location", false, 5);
        Hall hall3 = new Hall("Venues Apartment", "clean and tidy", true, 3);
        Hall hall4 = new Hall("Eruka Tower Apartment", "nice views", false, 6);
        Hall hall5 = new Hall("HFN Union Tower Apartment", "clean and tidy", true, 5);
        Hall hall6 = new Hall("Tomson Apartment", "nice location", false, 4);
        Hall hall7 = new Hall("Lily Road Apartment", "clean and tidy", false, 3);
        Hall hall8 = new Hall("Mimosa Tower Apartment", "nice location", true, 4);
        Hall hall9 = new Hall("Yarra Apartment", "clean and tidy", false, 3);
        Hall hall10 = new Hall("Osaka Tower Apartment", "nice views", true, 2);
        
        hallList.add(hall1);
        hallList.add(hall2);
        hallList.add(hall3);
        hallList.add(hall4);
        hallList.add(hall5);
        hallList.add(hall6);
        hallList.add(hall7);
        hallList.add(hall8);
        hallList.add(hall9);
        hallList.add(hall10);

        //Scanner scan = new Scanner(System.in);
        displayHomePage();
        String choice = scan.nextLine();
        if (!userStatus)
        {
            switch (choice) {
                case "1":
                    login();
                    break;
                case "2":
                    register();
                    break;
                case "3":
                    viewAllHalls();
                    break;
                case "4":
                    exit();
                    break;
                default:
                    System.out.println("Please enter a valid number from 1 - 4.");
            }
        }else
        {
            inSystem();
        }

    }
    
    public void inSystem()
    {
        userStatus = true;
        System.out.println("Customer press 1, Owner press 2.");
        String userType = scan.nextLine();
        try
        {
            if (userType.equals("1"))    
            {
                customerLogin();
            }
            else if (userType.equals("2"))
            {
                ownerLogin();
            }
        }
        catch (Exception e)
        {
            System.out.println("Error! Please try again!");
            login();
        }
    }
    
    public void customerLogin()
    {
        System.out.println("Hall Booking System");
        System.out.println("=============================================");
        System.out.println("1.Logout");
        System.out.println("2.Search a Hall");
        System.out.println("3.Book for a Hall");
        System.out.println("=============================================");
        System.out.println();
        System.out.print("Please enter your choice: ");
        
        String choice = scan.nextLine();
        if (choice.equals("1"))
        {
            userStatus = false;
            system();
        }
        else if (choice.equals("2"))
        {
            searchHall();
        }
        else if (choice.equals("3"))
        {
            bookHall();
        }
        else
        {
            System.out.println("Invalid! Please enter again!");
            customerLogin();
        }
    
    }
    
    public void searchHall()
    {
        System.out.println("");                  
        System.out.println("#############################################");                           
        System.out.println("#                                           #");                           
        System.out.println("#                  Welcome!                 #");                           
        System.out.println("#   Availble Hall are in the following list #");                           
        System.out.println("#                                           #");                           
        System.out.println("#                                           #");                           
        System.out.println("#############################################");                  
        System.out.println("");
        System.out.println("Search hall");                  
        System.out.println("=============================================");                 
        System.out.println("1.Searching by name");
        System.out.println("2.Cancel");                           
        System.out.println("=============================================");                  
        System.out.println();
        
        String choice = scan.nextLine();
        if (choice.equals("1"))
        {
            try
            {
                viewHallByName();
                
                requestQuotation();
                
            }catch(Exception ex) 
            {
                System.out.println("Invalid name!");
                searchHall();
            }
        }
        else if (choice.equals("2"))
        {
            customerLogin();
        }
        else
        {
            System.out.println("Invalid! Please enter again!");
            searchHall();
        }
    }
    
    public void requestQuotation()
    {
        System.out.println("Please enter type of event: ");
        String type = scan.nextLine();
        System.out.println("Please enter the number of the people");
        String number = scan.nextLine();
        System.out.println("Please enter the booking date (dd/mm/yyyy)");
        String date = scan.nextLine();
        System.out.println("Do you need catering service? (y/n)");
        String catering = scan.nextLine();
        System.out.println("Your quotation has been approved! Please press enter turn back to menu...");
        scan.nextLine();
        customerLogin();
    }
    
    public void bookHall()
    {
        System.out.println("");                  
        System.out.println("#############################################");                           
        System.out.println("#                                           #");                           
        System.out.println("#                  Welcome!                 #");                           
        System.out.println("#   Availble Hall are in the following list #");                           
        System.out.println("#                                           #");                           
        System.out.println("#                                           #");                           
        System.out.println("#############################################");                  
        System.out.println("");
        System.out.println("Book hall");                  
        System.out.println("=============================================");                 
        System.out.println("*********************************************");
        System.out.println("HallId");
        int id = 1;
        for (Hall h : hallList) {
            System.out.println("   " + id + " ---- " + h.getHallName());
            id += 1;
        }
        System.out.println("=============================================");                  
        System.out.println("");
        System.out.println("Please enter number to book hall: ");
        scan.nextLine();
        requestQuotation();
    }
    
    
    public void bookHallSuccess()
    {
        System.out.println("Your request has been approved!");
        scan.nextLine();
        System.out.println("Please pay deposit. It will be 10% of taotal price: " + "xxxxxxxxxxxxx");
        scan.nextLine();
        System.out.println("Please press to pay: ");
        scan.nextLine();
        System.out.println("Booking successfully!");
        scan.nextLine();
        customerLogin();
    }
    
    public void ownerLogin()
    {
        System.out.println("Hall Booking System");
        System.out.println("=============================================");
        System.out.println("1.Modify profile");
        System.out.println("2.Modify property");
        System.out.println("3.Exit");
        System.out.println("=============================================");
        System.out.println();
        System.out.print("Please enter your choice: ");
        
        String choice = scan.nextLine();
        
        if (choice.equals("1"))
        {
            ownerProfile();
        }
        else if (choice.equals("2"))
        {
            propertyInfo();
        }
        else if (choice.equals("3"))
        {
            userStatus = false;
            system();
        }
        else
        {
            System.out.println("Invalid! Please enter again!");
            customerLogin();
        }
    }
    
    public void ownerProfile()
    {
        System.out.println("Please enter your email:");
        String email = scan.nextLine();
        System.out.println("Please enter the information you want to modify:");
        System.out.println("Please enter your new name: ");
        String name = scan.nextLine();
        System.out.println("Please enter your new phone number:");
        String number = scan.nextLine();
        System.out.println("Please enter your new password:");
        String password = scan.nextLine();
        try{
            for (User u : userList) {
                if (u.getEmail().equals(email)) {
                    u.setUserName(name);
                    //u.setPhoneNo(number);
                    u.setPassword(password);
                }
            }
        }catch(Exception e)
        {
            System.out.println("Error! ");
            ownerProfile();
        }
        System.out.println("Modification success!");
        scan.nextLine();
        userStatus = false;
        system();
    }
    
    public void propertyInfo()
    {
        System.out.println("Please enter the hall name:");
        String n = scan.nextLine();
        System.out.println("Please enter hall address: ");
        String a = scan.nextLine();
        System.out.println("Please enter hall description: ");
        String d = scan.nextLine();
        System.out.println("Please enter hall price:");
        String p = scan.nextLine();
        try{
            for (Hall h : hallList) {
                if (h.getHallName().equals(n)) {
                    h.setHallName(n);
                    //h.setHallAddress(a);
                    h.setDescription(d);
                    //h.setHallPrice(p);
                }
            }
        }catch(Exception e)
        {
            System.out.println("Error! ");
            propertyInfo();
        }
        System.out.println("Modification success!");
        scan.nextLine();
        inSystem();
    }

    public void displayHomePage() {
        System.out.println("*********************************************");
        System.out.println("*            Hall Booking System            *");
        System.out.println("*            Press 1 to login               *");
        System.out.println("*            Press 2 to register            *");
        System.out.println("*            Press 3 to view all halls      *");
        System.out.println("*            Press 4 to exit                *");
        System.out.println("*********************************************");
    }

    public void login() {

        System.out.println("Please Enter Your Email:");
        String email = scan.nextLine();
        System.out.println("Please Enter Your Password:");
        String password = scan.nextLine();
        boolean flag = true;
        for (User u : userList) {
            if (u.getEmail().equals(email) && u.getPassword().equals(password)) {
                System.out.println("Welcome " + u.getUserName() + "!");
                flag = false;
            }
        }
        if (flag) {
            System.out.println("Fail to login: Invalid email & password.");
            login();
        }
        
        inSystem();
    }

    public void register() {
        //Scanner scan = new Scanner(System.in);
        System.out.println("Please Enter Your Email:");
        String email = scan.nextLine();
        System.out.println("Please Enter Your Password:");
        String password = scan.nextLine();
        System.out.println("Please Enter Your User Name:");
        String userName = scan.nextLine();
        System.out.println("Press 1 if you are a customer, press 2 if you are a property owner");
        String userType = scan.nextLine();
        boolean flag = true;
        for (User u : userList) {
            if (u.getEmail().trim().equals(email)) {
                flag = false;
            }
        }

        if (flag) {
            User user = new User(userName, email, password, userType);
            userList.add(user);
        } else {
            System.out.println("This email has already been registered.");
        }
        system();
    }

    public void exit() {
        System.out.println("*********************************************");
        System.out.println("*                                           *");
        System.out.println("*            Exit successfully.             *");
        System.out.println("*                                           *");
        System.out.println("*            See you next time!             *");
        System.out.println("*                                           *");
        System.out.println("*********************************************");
    }

    public void viewAllHalls() {
        //System.out.print('\u000C');
        System.out.println("*********************************************");
        System.out.println("HallId");
        int id = 1;
        for (Hall h : hallList) {
            System.out.println("   " + id + " ---- " + h.getHallName());
            id += 1;
        }
        System.out.println();
        System.out.println("*********************************************");
        System.out.println("Enter a hallId to view hall details.");
        System.out.println("Enter 0 to search a hall.");
        String choice = scan.nextLine();
        if (choice.equals("0")) {
            viewHallByName();
            System.out.println("Please enter number to book hall: ");
            
        } else {
            viewHallById(Integer.parseInt(choice), hallList);
        }
        requestQuotation();
    }

    public void viewHallById(int hallId, ArrayList<Hall> hallList) {
        try {
            if (hallId < hallList.size()) {
                hallList.get(hallId - 1).printHall();
            } else {
                System.out.println("Please enter a valid number.");
            }
        } catch (Exception ex) {
            System.out.println("Please enter a valid number.");
        }
    }

    public void viewHallByName() {
        System.out.println("Please enter the hall name: ");
        String hallName = scan.nextLine();
        System.out.println("*********************************************");
        for (Hall h : hallList) 
        {
            try
            {
                if (h.getHallName().contains(hallName)) 
                {
                    h.printHall();
                }
            }catch(Exception e)
            {
                System.out.println("Hall does not exist!");
            }
        }
    }
}
