
public class Hall {
    private String hallName;
    private String description;
    private boolean availability;
    private int rating;

    public Hall() {
    }

    public Hall(String hallName, String description, boolean availability, int rating) {
        this.hallName = hallName;
        this.description = description;
        this.availability = availability;
        this.rating = rating;
    }

    public String getHallName() {
        return hallName;
    }

    public void setHallName(String hallName) {
        this.hallName = hallName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isAvailability() {
        return availability;
    }

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public void printHall() {
        System.out.println("Hall{" + "Hall Name:" + hallName + ", Description:" + description + ", Availability=" + availability + ", Rating=" + rating + '}');
    }


}