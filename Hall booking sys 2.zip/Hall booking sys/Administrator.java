
/**
 * Write a description of class Administrator here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Administrator extends User {
    public Administrator() {
    }

    public Administrator(String userName, String email, String password, String userType) {
        super(userName, email, password, userType);
    }
}
