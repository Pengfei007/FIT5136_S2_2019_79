
/**
 * Write a description of class Customer here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Customer extends User {
    private String customerStatus;
    private int creditCardNo;
    private int phoneNo;
    private int accountBalance;
    private String bookingHistory;

    public Customer(String customerStatus, int creditCardNo, int phoneNo, int accountBalance, String bookingHistory, String userName, String email, String password, String userType) {
        super(userName, email, password, userType);
        this.customerStatus = customerStatus;
        this.creditCardNo = creditCardNo;
        this.phoneNo = phoneNo;
        this.accountBalance = accountBalance;
        this.bookingHistory = bookingHistory;
    }

    public String getCustomerStatus() {
        return customerStatus;
    }

    public void setCustomerStatus(String customerStatus) {
        this.customerStatus = customerStatus;
    }

    public int getCreditCardNo() {
        return creditCardNo;
    }

    public void setCreditCardNo(int creditCardNo) {
        this.creditCardNo = creditCardNo;
    }

    public int getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(int phoneNo) {
        this.phoneNo = phoneNo;
    }

    public int getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(int accountBalance) {
        this.accountBalance = accountBalance;
    }

    public String getBookingHistory() {
        return bookingHistory;
    }

    public void setBookingHistory(String bookingHistory) {
        this.bookingHistory = bookingHistory;
    }
}
