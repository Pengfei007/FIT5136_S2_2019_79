
/**
 * Write a description of class Owner here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Owner extends User {
    private int creditCardNo;
    private int phoneNo;
    private int accountBalance;

    public Owner(int creditCardNo, int phoneNo, int accountBalance, String userName, String email, String password, String userType) {
        super(userName, email, password,userType);
        this.creditCardNo = creditCardNo;
        this.phoneNo = phoneNo;
        this.accountBalance = accountBalance;
    }

    public int getCreditCardNo() {
        return creditCardNo;
    }

    public void setCreditCardNo(int creditCardNo) {
        this.creditCardNo = creditCardNo;
    }

    public int getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(int phoneNo) {
        this.phoneNo = phoneNo;
    }

    public int getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(int accountBalance) {
        this.accountBalance = accountBalance;
    }

}
